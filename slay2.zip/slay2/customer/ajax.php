<?
  include_once "../connect.php";
  $query = "SELECT * FROM `register`, `customer` WHERE `date` = ".'"'.$_GET['date'].'"'." AND `gasstation_id` = ".$_GET['adress'];
  $result = mysqli_query($connect, $query);
  print_r( json_encode( mysqli_fetch_all($result) ));
?>