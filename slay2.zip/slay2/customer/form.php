<?php
  include_once "../connect.php";
  $queryTime = "SELECT * FROM `ranges`";
  $resultTime = mysqli_query($connect, $queryTime);
  $lenresult = (mysqli_fetch_all($resultTime));
  if(isset($_GET['id'])) {
    $district_id = $_GET['id'];
    $queryAddress = "SELECT * FROM `district`, `gas stations` WHERE `gas stations`.`DISTRICT_ID` = `district`.`id` AND `district`.`id` = $district_id";
    $resultAddress = mysqli_query($connect, $queryAddress);
    if(isset($_POST['click'])) {
      $name = addslashes($_POST['name']);
      $surname = addslashes($_POST['surname']);
      $phoneNum = $_POST['phoneNum'];
      $carNum = $_POST['carNum'];
      $address = addslashes($_POST['address']);
      $date = $_POST['date'];
      $time = $_POST['time'];
      
      $query = "INSERT INTO `customer` (`ID_NAME`, `PHONE_NUMBER`, `DATE`, `TIME`, `CAR_NUMBER`, `NAME`, `SURNAME`) VALUES
                           ($address,'$phoneNum','$date',$time,'$carNum','$name','$surname')";
      mysqli_query($connect, $query);
      header("Location: https://t.me/SlayQbot");
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Slay Queue</a>
    
    <div class="" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
        <li class="nav-item">
          <a class="nav-link" href="search1.php">Back</a>
        </li>
        
        
      </ul>
    </div>
  </div>
</nav>
  <form action="" method="POST" style="margin-top: 10vh">
    <div class="form-row">
      <h2 class="text-light">Customer Registration</h2>
      <div class="form-group col-md-12">
        <label for="inputName" class="text-light">Name</label>
        <input type="text" class="form-control" id="inputName" placeholder="Name" name="name">
      </div>
      <div class="form-group col-md-12">
        <label for="inputSurname" class="text-light">Surname</label>
        <input type="text" class="form-control" id="inputSurname" placeholder="Surname" name="surname">
      </div>
      
    </div>
    <div class="form-group">
      <label for="inputNumber" class="text-light">Phone Number</label>
      <input type="phone" class="form-control" id="inputNumber" placeholder="Phone Number" name="phoneNum">
    </div>
    <div class="form-group">
      <label for="inputCarnum" class="text-light">Car Number</label>
      <input type="number" class="form-control" id="inputCarnum" placeholder="Car Number" name="carNum">
    </div>
    <div class="form-group">
      <label for="inputAddress" class="text-light" >Address</label>
      <select id="inputAddress" class="form-control" name="address" onselect="info(document.getElementById('inputAddress').value,this.value)">
          <?php
            while($rowAddress = mysqli_fetch_assoc($resultAddress)) {
          ?>
          <option class="address" id="inputAddress" value="<?php echo $rowAddress['ID']?>"><?php echo $rowAddress['NAME']?></option>
          <?php
            }
          ?>
        </select>
    </div>
    
    <div class="form-row">
      <div class="form-group col-md-12">
      <!-- //date bazadan -->
        <label for="inputDate" class="text-light" >Date</label> 
        <input type="date" class="form-control" id="inputDate" name="date" oninput="info(this.value,document.getElementById('inputAddress').value)">
      </div>
      <div class="form-group col-md-12" >
      <!-- //time bazadan -->
      
        <label for="inputTime" class="text-light">Time</label> 
        <select id="inputTime" class="form-control" name="time" >
          <?php
            foreach($lenresult as $rowTime) {
          ?>
          <option class="times" id="time-<?=$rowTime[0]?>" value="<?=$rowTime[0]?>"><?=$rowTime[1]?> - <?=$rowTime[2]?> (20)</option>
          <?php
            }
          ?>
        </select>
      </div>
      
    </div><br>
  
    
    <button type="submit" style ="height: 10px; padding-top:5px" class="col-10" name="click">Click</button>
  </form>
  <script>
   
   

    function info(date,adress){
      for (var i = 1, len = <? echo count($lenresult) ?>; i <= len; i++) {
          var time_id = document.getElementById('time-'+i).innerHTML.split('(')
          document.getElementById('time-'+i).innerHTML=time_id[0]+' (20)'
        }
      if (date.length == 0) {
        return;
      } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            var data=JSON.parse( this.responseText )
            
            data.forEach((obj) => {
              var time_id = document.getElementById('time-'+obj[4]).innerHTML.split('(')
              var num = time_id[1].slice(0, -1)-1
              document.getElementById('time-'+obj[4]).innerHTML=time_id[0]+' ('+num+')'
            })
          }
        };
        xmlhttp.open("GET", "ajax.php?date=" + date+'&adress='+adress, true);
        xmlhttp.send();
      }
    }

  </script>
</body>
</html>
