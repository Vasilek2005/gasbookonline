<?php
  include_once "../connect.php";
  $queryDistrict = "SELECT * FROM `district`";
  $resultDistrict = mysqli_query($connect, $queryDistrict);
  if(isset($_POST['click'])) {
   
    $district = $_POST['district'];
   
    
    $query = "INSERT INTO `customer`(`ID_NAME`, `PHONE_NUMBER`, `DATE`, `TIME`, `CAR_NUMBER`, `NAME`, `SURNAME`) VALUES ([value-1],$phoneNum,$date,$time,$carNum,'$name','$surname')";
    $query1 = "INSERT INTO `register`(`gasstation_id`, `customer_id`, `range_id`) VALUES ([value-2],[value-3],$time)";
  
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<style>
    html, body {
        overflow: auto !important;
    }
</style>
<body>
    <div class="container text-center my-2">
    <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Slay Queue</a>
    
    <div class="" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
        <li class="nav-item">
          <a class="nav-link" href="main.php">Back</a>
        </li>
        
        
      </ul>
    </div>
  </div>
</nav>
        <div class="" style="margin-top: 20vh">
             <form method="POST">
             <div style="height: 40vh; font-size: 30px; display: flex; margin-bottom: 30px; justify-content: center; align-items: flex-end; color: white !important;">Choose one of them:</div>
             <div>
            <?php
                while($rowDistrict = mysqli_fetch_assoc($resultDistrict)) {
            ?>
            <button class="col-md-3" ><a href="form.php?id=<?=$rowDistrict['ID']?>" class="text-light"><?=$rowDistrict['DISTRICT1']?></a></button><br><br>
            <?php
                }
            ?>
            </div>
            </form>
            
    </div>
            
    
    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html>