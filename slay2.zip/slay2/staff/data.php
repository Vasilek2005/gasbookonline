<?php
   include_once "../connect.php";
   $staffId = $_GET['id'];
   // echo $staffId;
   $queryGas = "SELECT * FROM `gas stations` WHERE `ID` = $staffId";
   $resultGas = mysqli_query($connect, $queryGas);
   $rowGas = mysqli_fetch_assoc($resultGas);
   $queryRanges = "SELECT * FROM `ranges`";
   $resultRanges = mysqli_query($connect, $queryRanges);
   $rowRanges = mysqli_fetch_assoc($resultRanges);

   $query = "SELECT * FROM `customer`, `gas stations`, `register` WHERE `gas stations`.`ID` = $staffId AND `gas stations`.`ID` = `customer`.`ID_NAME` AND `gas stations`.`ID`=`register`.`gasstation_id`";
   $result = mysqli_query($connect, $query);
   $row = mysqli_fetch_assoc($result);
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Users</title>
    <!-- <link rel="stylesheet" href="../assets/css/style.css"> -->
    <style>
      body, html {
         height: 100%;
         text-align: center;
      }
      body {
         font-family: 'Mulish', sans-serif;
         background: white;
         display: flex;
         justify-content: center;
         flex-direction: column;
         align-items: center;
      }
      .nav {
         list-style-type: none;
         border-radius: 10px;
         background: #666;
         margin: 0;
         padding: 0;
         width: 300px;
         overflow: hidden;
      }

      .nav-item {
         font-size: 20px;
         background: #2F5D9D;
         border-bottom: 1px solid rgba(63, 46, 73, 0.3);
      }

      .nav-item:last-child {
         border-bottom: none;
      }

      .nav-link, .nav-submenu-link {
         text-decoration: none;
         padding: 16px 20px;
         display: block;
         color: #fff;
      }

      .nav-submenu {
         overflow: hidden;
         max-height: 0;
         transition: max-height 0.5s;
         background: #3f2e49;
      }
      .nav-submenu:target {
         max-height: 10rem;
      }
      .nav-submenu-link {
         font-size: 16px;
         background: transparent;
         transition: background 0.2s ease-in;
      }
      .nav-submenu-link:hover {
         background: #36253f;
      }
    </style>
</head>
<body>
      <h2>Users registered for<br><?=$rowGas['NAME']?></h2>
      <ul class="nav"> 
         <li class="nav-item">
            <?php while($rowRanges = mysqli_fetch_assoc($resultRanges)){ ?>
               <a href="#profile" class="nav-link"><?=$rowRanges['start_time']?> - <?=$rowRanges['end_time']?></a>
            <div id="profile" class="nav-submenu">
               <a href="#" class="nav-submenu-link">Posts</a>
               <a href="#" class="nav-submenu-link">Images</a>
            </div>
            <?php } ?>
            

            
         </li>
         
         
         <li class="nav-item">
            <a href="#exit" class="nav-link">Exit</a>
         </li>
         
      </ul>
  
</body>
</html>