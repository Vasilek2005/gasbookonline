<?php
  include "../connect.php";
  $queryDistrict = "SELECT * FROM `district`";
  $resultDistrict = mysqli_query($connect, $queryDistrict);
  if (isset($_POST['submit']) ) {
    $district_id=addslashes($_POST['district_id']);
    $login = addslashes($_POST['login']);
    $password = addslashes($_POST['password']);
    $name=addslashes($_POST['name']);
    $surov = "INSERT INTO `gas stations`(DISTRICT_ID, STAFF_LOGIN, STAFF_PASSWORD,NAME) VALUES('$district_id','$login','$password','$name')";
    $query = mysqli_query($connect, $surov);
    if ($query == true) {
      header('Location:login.php');
    } else {
      echo "xatolik bor";
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Staff</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="container text-light">
  <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Slay Queue</a>
    
    <div class="" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
        <li class="nav-item">
          <a class="nav-link" href="login.php">Back</a>
        </li>
        
        
      </ul>
    </div>
  </div>
</nav>
    <div class="">
      <div class="row">
        <div class="col-12 my-5">
          <h3>Add Staff</h3>
            <form action="" method="POST" enctype="multipart/form-data">
              <div class="mb-3 col-12">
                <label for="exampleInputEmail1" class="form-label">District</label>
                <select id="inputDistrict" class="form-control" name="district_id">
                  <?php
                    while($rowDistrict = mysqli_fetch_assoc($resultDistrict)) {
                  ?>
                  <option value="<?=$rowDistrict['ID']?>"><?=$rowDistrict['DISTRICT1']?></option>
                  <?php
                    }
                  ?>
                </select>
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Login</label>
                <input type="text" name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Password</label>
                <input name="password" class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <button type="submit" style ="height: 10px; padding-top:5px" class="col-10" name ="submit" class="btn btn-primary">Add staff</button>
            </form>
          </div>
        </div>  
      </div>
  </body>
</html>