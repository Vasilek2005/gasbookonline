<?php
   include_once "../connect.php";
   $staffId = $_GET['id'];

   $queryGas = "SELECT * FROM `gas stations` WHERE `ID` = $staffId";
   $resultGas = mysqli_query($connect, $queryGas);
   $rowGas = mysqli_fetch_assoc($resultGas);
   $queryRanges = "SELECT * FROM `ranges`";
   $resultRanges = mysqli_query($connect, $queryRanges);
   $rowRanges = mysqli_fetch_assoc($resultRanges);

   $query = "SELECT *, COUNT(*) AS `num`, `customer`.`NAME` as `user` FROM `customer`, `gas stations`, `ranges` WHERE `gas stations`.ID = $staffId AND `gas stations`.ID = customer.ID_NAME AND `ranges`.`ID` = `customer`.`TIME`";
   $result = mysqli_query($connect, $query);

   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <title>Registered Users</title>
    <!-- <link rel="stylesheet" href="../assets/css/style.css"> -->
    <style>
      body, html {
         height: 100%;
         text-align: center;
      }
      body {
         font-family: 'Mulish', sans-serif;
         background: #2F5D9D;
         display: flex;
         justify-content: center;
         flex-direction: column;
         align-items: center;
      }
      .nav {
         list-style-type: none;
         border-radius: 10px;
         background: #666;
         margin: 0;
         padding: 0;
         width: 300px;
      }
      .nav-submenu {
         overflow: hidden;
         max-height: 0;
         transition: max-height 0.5s;
         background: #3f2e49;
      }
      .nav-submenu:target {
         max-height: 10rem;
      }
      .nav-submenu-link {
         font-size: 16px;
         background: transparent;
         transition: background 0.2s ease-in;
      }
      .nav-submenu-link:hover {
         background: #36253f;
      }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Slay Queue</a>
    
    <div class="" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
        <li class="nav-item">
          <a class="nav-link" href="login.php">Back</a>
        </li>
        
        
      </ul>
    </div>
  </div>
</nav>
      <h2 class="text-light">Customers registered for<br><?=$rowGas['NAME']?></h2>
      <?php
         //while($row = mysqli_fetch_assoc($result)) {

               while($row = mysqli_fetch_assoc($result)) {
                  if($row['num'] == 0) {
                     echo '<p class="card-text text-light">There is no registered customers.</p>';
                  } else {
      ?>
            <div class="card" style="width: 18rem;">
            <div class="card-body">
               <h5 class="card-title"></h5>
               <h6 class="card-subtitle mb-2 text-body-dark"><?=$row['user']?> <?=$row['SURNAME']?></h6>
               <p class="card-text"><b>Date:</b> <?=$row['DATE']?><br><b>Time:</b> <?=$row['start_time']?> - <?=$row['end_time']?><br><b>Car number:</b> <?=$row['CAR_NUMBER']?><br><b>Phone number:</b> <?=$row['PHONE_NUMBER']?></p>
            </div>
            </div>
      <?php
                  }
            }
      
      ?>

  
</body>
</html>