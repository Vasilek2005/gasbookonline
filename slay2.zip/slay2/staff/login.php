<?php
    ob_start();
    include_once "../connect.php";
    if(isset($_POST['submit'])) {
        $login = addslashes($_POST['login']);
        $password = addslashes($_POST['password']);
        $query = "SELECT COUNT(*) AS `num`, `ID` FROM `gas stations` WHERE `STAFF_LOGIN` LIKE '$login' AND `STAFF_PASSWORD` LIKE '$password'";
        //echo "SELECT * FROM `gas stations` WHERE `STAFF_LOGIN` LIKE '$login' AND `STAFF_PASSWORD` LIKE '$password'";
        $result = mysqli_query($connect,  $query);
        $row = mysqli_fetch_assoc($result);
        if ($row['num'] == 1) {
            echo $row['ID'];
            header("Location: data2.php?id=".$row['ID']);
        } else {
            echo 'Error';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container text-center">
    <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Slay Queue</a>
    
    <div class="" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
        <li class="nav-item">
          <a class="nav-link" href="../index.php">Back</a>
        </li>
        
        
      </ul>
    </div>
  </div>
</nav>
        <div class="my-3">
            <form method="POST">
                <div class="form-row">
                    <h1 class="text-light">Staff Login</h1>
                    <div class="form-group col-md-12">
                        <label for="inputLogin" class="text-light">Login</label>
                        <input type="text" class="form-control" id="inputLogin" placeholder="Login" name="login">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="inputPassword" class="text-light">Password</label>
                        <input type="password" class="form-control" id="inputPassword" placeholder="Password" name="password">
                    </div>
                </div><br>  
                <button type="submit" style ="height: 10px; padding-top:5px" name="submit">Login</button><br>
                <a href="createstaff.php" class="text-light">Sign up</a>
            </form>
        </div>
    </div>
</body>
</html>