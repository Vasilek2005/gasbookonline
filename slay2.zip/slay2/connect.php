<?php
    define("HOST","localhost");
    define("BAZA","search1");
    define("PASSWORD","");
    define("USER","root");

    $connect = mysqli_connect(HOST,USER,PASSWORD,BAZA);
?>